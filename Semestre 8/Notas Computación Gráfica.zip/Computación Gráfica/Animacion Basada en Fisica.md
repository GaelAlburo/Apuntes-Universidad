Links:
___

Su pipeline costa de 4 etapas:
1. Modelado Conceptual
	- Cada vertice se le da propiedades cinematicas (posicion, velocidad, aceleracion) y una masa
2. Modelado Matematico
3. Modelado Numerico
4. Modelado Computacional