Links:
___

Fuentes de energia luminosa:
- Directa (Metodos locales)
	- Se considera solo como actua una fuente sobre un objeto y como lo ve el observador
	- **Es el que se usara en el proyecto**
	- Componentes ambientales, difusas y especulares
- Indirecta (Metodos globales)
	- Se consideran multiples objetos, observadores y fuentes de energia
	- Trazado de rayos

La **iluminacion** es el conjunto de elementos que brindan **color, visibilidad y efecto de profundidad** a un objeto



Todos los elementos dinamicos deben ir en coordenadas de modelo (el origen)
