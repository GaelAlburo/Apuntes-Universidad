____

Dr. Sergio Teodoro Vite
sergio.teodoro@ingenieria.unam.edu
Plataforma del curso: https://computer-graphics.com.mx

De Vrites. Learn OpenGL

Evaluación
- Primer Parcial - 15%
- Segundo Parcial - 15%
- Asistencia - 10%
- Tareas (5) - 10%
- Lab - 30%
- Proyecto Final - 20%