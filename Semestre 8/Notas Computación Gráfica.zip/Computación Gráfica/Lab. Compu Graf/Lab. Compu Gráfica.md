Links: [[Temario Compu Grafica]]
___

- [[Universidad/Semestre 8/Computación Gráfica/Lab. Compu Graf/Practica 1|Practica 1]]
- 